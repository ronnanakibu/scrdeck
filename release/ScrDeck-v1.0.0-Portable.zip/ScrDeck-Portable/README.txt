ScrDeck Portable v1.0.0
=======================

Quick Start:
1. Extract all files to a folder of your choice.
2. Double-click `scrdeck.exe` to launch ScrDeck.
3. Ensure `WebView2Loader.dll` remains in the same directory as `scrdeck.exe`.

Requirements:
- Windows 10 (Build 1809+) or Windows 11
- Microsoft Edge WebView2 Runtime (preinstalled on Windows 10/11, or auto-installed)

Documentation & Support:
https://github.com/ronnanakibu/scrdeck
